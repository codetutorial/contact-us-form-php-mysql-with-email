<?php
require 'config.php';

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

print_r($_POST);
print_r($_FILES);

extract($_POST);

if(isset($_FILES['uploaded_file']['name'])){
// get information from uplaoded file 

$filename = basename($_FILES['uploaded_file']['name']);

// copy this file from temp to folder
$new_path = './files/'.$filename;
$temp_path = $_FILES['uploaded_file']['tmp_name'];

if(is_uploaded_file($temp_path)){

if(!copy($temp_path,$new_path)){
   echo "Something went wrong in file upload";
}

$mail = new PHPMailer\PHPMailer\PHPMailer();
try{

    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'youremail@gmail.com';                     // SMTP username //must enable less secure apps use
    $mail->Password   = 'yourpassword';                               // SMTP password
    $mail->SMTPSecure = 'ssl';         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
    $mail->Port       = 465;                                    // TCP port to connect to

    //Recipients
    $mail->setFrom('from@example.com', 'your name');
    $mail->addAddress('emailwhereyouwanttoreciveemail', 'your name');     // Add a recipient
    

    // Attachments
    $mail->addAttachment($new_path, $filename);    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'New Feedback from ContactUs form';
    $mail->Body    = 'Hello You have new feedback from website!! Details below <br> <b>Name : </b>'.$firstname.' '.$lastname.' <br> <b>Phone : </b>'.$phone.'<br> <b>Email : </b>'.$email.'  <br> <b>Message : </b>'.$message ;

    if(!$mail->Send()) {
      echo "Mailer Error: " . $mail->ErrorInfo;
      } else {
      echo "Message has been sent";
      $sql = "INSERT INTO `contactdata`(`firstname`, `lastname`, `phone`, `email`, `message`,`attachement`) VALUES ('".$firstname."','".$lastname."',".$phone.",'".$email."','".$message."','".$filename."')";
      $result = $mysqli->query($sql);
      if(!$result){
         die("Couldn't enter data: ".$mysqli->error);
              }
      echo "Thank You For Contacting Us ";
      $mysqli->close(); 

      }

}catch(Exception $e){
echo "mail could not be send error: ". $mail->ErorrInfo;
}

}
}
  

?>